import React from 'react'

const page = () => {
  return (<>
    <div className='text-6xl'>Documentation</div>
    <div className='text-6xl'>Copy ShadnCn, NextJS, Notion, etc for professionalisium</div>
  </>
  )
}

export default page
